"""Dashboard serialization helpers."""
